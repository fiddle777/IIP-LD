[![Build](https://github.com/googlemaps-samples/android-samples/actions/workflows/build.yml/badge.svg)](https://github.com/googlemaps-samples/android-samples/actions/workflows/build.yml)

![Contributors](https://img.shields.io/github/contributors/googlemaps-samples/android-samples?color=green)
[![License](https://img.shields.io/github/license/googlemaps-samples/android-samples?color=blue)][license]
[![StackOverflow](https://img.shields.io/stackexchange/stackoverflow/t/google-maps?color=orange&label=google-maps&logo=stackoverflow)](https://stackoverflow.com/questions/tagged/android+google-maps)
[![Discord](https://img.shields.io/discord/676948200904589322?color=6A7EC2&logo=discord&logoColor=ffffff)][Discord server]

# Google Maps SDK for Android Samples

<img src="images/screenshots.png" width="1164" />

## Description

Samples demonstrating how to use
[Maps SDK for Android](https://developers.google.com/maps/documentation/android-sdk).

## Samples in this repo (if more than one)

This repo contains the following samples:

1. [ApiDemos](ApiDemos): A collection of small demos showing most features of the Maps SDK for Android.
2. [FireMarkers](FireMarkers): Demonstrates how to use Firebase Realtime Database to drive synchronized, live animations on a Google Map across multiple devices using a controller/agent architecture.
3. [WearOS](WearOS):
Displays a map on a Wear OS device. This sample demonstrates the basic
setup required for a gradle-based Android Studio project.
4. [Tutorials](https://github.com/googlemaps/android-samples/tree/main/tutorials): Samples
associated with tutorials in the developer's guide. See each sample for a link to the associated guide.
5. [Snippets](snippets): Snippets for code found in https://developers.google.com/maps/documentation/android-sdk

## Requirements

To run the samples, you will need:

- To [sign up with Google Maps Platform]
- A Google Maps Platform [project] with the **Maps SDK for Android** enabled
- An [API key] associated with the project above ... follow the [API key instructions] if you're new to the process
- See each sample for pre-requisites.
- All require up-to-date versions of the Android build tools and the Android support repository.

## Running the sample(s)

1. Download the samples by cloning this repository
1. In the welcome screen of Android Studio, select "Open an Existing project"
1. Select the root directory of this repository (android-samples)

## Verifying the build

### Interactive Falsifiable Verification Dashboard
We provide an interactive web dashboard (`MANUAL_VERIFY_CATALOG.html`) and live execution API server (`test/server.py`) that allows stepping through and evaluating all 39 SDK capabilities across both Kotlin and Java live on attached devices.

👉 **See the [Verification Tool Guide](VERIFICATION_TOOL_GUIDE.md) for full instructions on how to start the server, use the UI controls, and automate evaluations via AI agents.**

### Command Line Verification
To verify that all samples build and pass tests via CLI, run:

```bash
./scripts/verify_all.sh
```

To run instrumentation tests on a connected device or emulator, use:

```bash
# For Wear OS devices/emulators
./scripts/verify_all.sh --connected-wear

# For Mobile (Handheld) devices/emulators
./scripts/verify_all.sh --connected-mobile
```

Alternatively, use the `gradlew build` command to build the project directly or download an APK
under [releases](https://github.com/googlemaps/android-samples/releases).

## Internal usage attribution ID

This library calls the `addInternalUsageAttributionId` method, which helps Google understand which libraries and samples are helpful to developers and is optional. Instructions for opting out of the identifier are provided below.

If you wish to disable this, you can do so by removing the initializer in your `AndroidManifest.xml` using the `tools:node="remove"` attribute:

```xml
<provider
    android:name="androidx.startup.InitializationProvider"
    android:authorities="${applicationId}.androidx-startup"
    android:exported="false"
    tools:node="merge">
    <meta-data
        android:name="com.example.library.utils.attribution.AttributionIdInitializer"
        tools:node="remove" />
</provider>
```

## Contributing

Contributions are welcome and encouraged! If you'd like to contribute, send us a [pull request] and refer to our [code of conduct] and [contributing guide].

## Terms of Service

This sample uses Google Maps Platform services. Use of Google Maps Platform services through this sample is subject to the Google Maps Platform [Terms of Service].

If your billing address is in the European Economic Area, effective on 8 July 2025, the [Google Maps Platform EEA Terms of Service](https://cloud.google.com/terms/maps-platform/eea) will apply to your use of the Services. Functionality varies by region. [Learn more](https://developers.google.com/maps/comms/eea/faq).

This sample is not a Google Maps Platform Core Service. Therefore, the Google Maps Platform Terms of Service (e.g. Technical Support Services, Service Level Agreements, and Deprecation Policy) do not apply to the code in this sample.

## Support

This sample is offered via an open source [license]. It is not governed by the Google Maps Platform Support [Technical Support Services Guidelines], the [SLA], or the [Deprecation Policy]. However, any Google Maps Platform services used by the sample remain subject to the Google Maps Platform Terms of Service.

If you find a bug, or have a feature request, please [file an issue] on GitHub. If you would like to get answers to technical questions from other Google Maps Platform developers, ask through one of our [developer community channels]. If you'd like to contribute, please check the [contributing guide].

You can also discuss this sample on our [Discord server].

[android-sdk]: https://developers.google.com/maps/documentation/android-sdk
[API key]: https://developers.google.com/maps/documentation/android-sdk/get-api-key
[API key instructions]: https://developers.google.com/maps/documentation/android-sdk/config#step_3_add_your_api_key_to_the_project

[code of conduct]: ?tab=coc-ov-file#readme
[contributing guide]: CONTRIBUTING.md
[Deprecation Policy]: https://cloud.google.com/maps-platform/terms
[developer community channels]: https://developers.google.com/maps/developer-community
[Discord server]: https://discord.gg/hYsWbmk
[file an issue]: https://github.com/googlemaps-samples/android-samples/issues/new/choose
[license]: LICENSE
[pull request]: https://github.com/googlemaps-samples/android-samples/compare
[project]: https://developers.google.com/maps/documentation/android-sdk/cloud-setup#enabling-apis
[Sign up with Google Maps Platform]: https://console.cloud.google.com/google/maps-apis/start
[SLA]: https://cloud.google.com/maps-platform/terms/sla
[Technical Support Services Guidelines]: https://cloud.google.com/maps-platform/terms/tssg
[Terms of Service]: https://cloud.google.com/maps-platform/terms

