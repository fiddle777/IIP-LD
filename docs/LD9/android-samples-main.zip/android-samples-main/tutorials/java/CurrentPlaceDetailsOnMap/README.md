Google Maps Android API Sample: Current Place Details
=====================================================

This sample goes hand in hand with a tutorial for the Google Maps Android API:
[Select Current Place and Show Details on a Map](https://developers.google.com/maps/documentation/android-api/current-place-tutorial).

Prerequisites
--------------

- Android API level 24+
- Latest Android Build Tools
- Android Support Repository
- Google Repository
- Google Play Services

Getting started
---------------

This sample uses the Gradle build system.

1. Download the samples by cloning this repository or downloading an archived
  snapshot. (See the options at the top of the page.)
1. In Android Studio, create a new project and choose the "Import non-Android Studio project" or
  "Import Project" option.
1. Select the `CurrentPlaceDetailsOnMap` directory that you downloaded with this repository.
1. If prompted for a gradle configuration, accept the default settings.
  Alternatively use the `gradlew build` command to build the project directly.

This demo app requires that you add your own Google Maps API key. See [Get an API key](https://developers.google.com/maps/documentation/android-sdk/get-api-key) for more instructions.

The app uses the Places SDK for Android (New), so the API key must have
[Places API (New)](https://developers.google.com/maps/documentation/places/android-sdk/cloud-setup)
enabled in addition to the Maps SDK for Android.

This sample is part of the root Gradle build. From the root of this repository, add your key to
`secrets.properties` (see `local.defaults.properties` for the format) and run:

```
./gradlew :tutorials:java:CurrentPlaceDetailsOnMap:assembleDebug
```

Support
-------

- Stack Overflow: https://stackoverflow.com/questions/tagged/android+google-maps

If you have discovered an issue with the Google Maps Android API v2, please see
the resources here: https://developers.google.com/maps/documentation/android-sdk/support

If you've found an error in these samples, please file an issue:
https://github.com/googlemaps/android-samples/issues

![Analytics](https://ga-beacon.appspot.com/UA-12846745-20/android-samples-apidemos/readme?pixel)

License
-------

Please refer to the [LICENSE](https://github.com/googlemaps/android-samples/blob/main/LICENSE) at the root of this repo.
