# Consumer Proguard rules
