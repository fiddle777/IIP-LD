// Copyright 2020 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.example.mapdemo;

import android.os.Bundle;
import com.example.common_ui.R;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;

/**
 * This shows how to use Cloud-based Map Styling in a simple Activity. For more information on how
 * to style a map using this method, see:
 * https://developers.google.com/maps/documentation/android-sdk/cloud-based-map-styling
 */
public class CloudBasedMapStylingDemoActivity extends SamplesBaseActivity
        implements OnMapReadyCallback {

    private static final String MAP_TYPE_KEY = "map_type";
    private GoogleMap map;
    private int currentMapType = GoogleMap.MAP_TYPE_NORMAL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            currentMapType = savedInstanceState.getInt(MAP_TYPE_KEY);
        }

        // The underlying style the map will use has been set in the layout
        // `cloud_styling_basic_demo` under the SupportMapFragment's `map:mapId` attribute.
        setContentView(R.layout.cloud_styling_basic_demo);
        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        setUpButtonListeners();
        applyInsets(findViewById(R.id.map_container));
    }

    @Override
    public void onMapReady(GoogleMap map) {
        this.map = map;
        map.setMapType(currentMapType);
        LatLng montBlanc = new LatLng(45.8326, 6.8652);
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(montBlanc, 11.5f));
    }

    private void setUpButtonListeners() {
        findViewById(R.id.styling_normal_mode)
                .setOnClickListener(v -> setMapType(GoogleMap.MAP_TYPE_NORMAL));
        findViewById(R.id.styling_satellite_mode)
                .setOnClickListener(v -> setMapType(GoogleMap.MAP_TYPE_SATELLITE));
        findViewById(R.id.styling_hybrid_mode)
                .setOnClickListener(v -> setMapType(GoogleMap.MAP_TYPE_HYBRID));
        findViewById(R.id.styling_terrain_mode)
                .setOnClickListener(v -> setMapType(GoogleMap.MAP_TYPE_TERRAIN));
    }

    private void setMapType(int mapType) {
        currentMapType = mapType;
        map.setMapType(mapType);
    }
}
