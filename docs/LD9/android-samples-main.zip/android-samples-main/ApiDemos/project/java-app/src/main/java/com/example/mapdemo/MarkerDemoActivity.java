// Copyright 2026 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.example.mapdemo;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.animation.BounceInterpolator;
import android.view.animation.Interpolator;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.ColorInt;
import androidx.annotation.DrawableRes;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import com.example.common_ui.R;
import com.example.common_ui.catalog.Complexity;
import com.example.common_ui.catalog.Framework;
import com.example.common_ui.catalog.Sample;
import com.example.common_ui.databinding.MarkerDemoBinding;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.InfoWindowAdapter;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowCloseListener;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowLongClickListener;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;
import com.google.android.gms.maps.GoogleMap.OnMarkerDragListener;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** This shows how to place markers on a map. */
@Sample(
        id = "marker_demo",
        title = "Standard Markers & Info Windows",
        description =
                "Placing markers, custom icons, draggable pins (long press Melbourne to drag), and custom info window layouts.",
        category = "Markers & Overlays",
        complexity = Complexity.SIMPLE,
        tags = {"#markers", "#infowindow", "#draggable", "#icons", "#anchor"},
        purpose =
                "Demonstrates adding standard markers with alpha, rotation, draggable pins (long press Melbourne to drag), and custom InfoWindowAdapter views.",
        successCriteria =
                "Tapping markers displays custom info windows with formatted content; dragging pins updates position.",
        failureIndicators =
                "Info window clicks not detected or custom snippet styling not applied.",
        framework = Framework.JAVA_VIEWS)
// [START maps_android_sample_marker]
public class MarkerDemoActivity extends SamplesBaseActivity
        implements OnMarkerClickListener,
                OnInfoWindowClickListener,
                OnMarkerDragListener,
                OnSeekBarChangeListener,
                OnInfoWindowLongClickListener,
                OnInfoWindowCloseListener,
                OnMapAndViewReadyListener.OnGlobalLayoutAndMapReadyListener {

    private static final LatLng BRISBANE = new LatLng(-27.47093, 153.0235);

    private static final LatLng MELBOURNE = new LatLng(-37.81319, 144.96298);

    private static final LatLng DARWIN = new LatLng(-12.4634, 130.8456);

    private static final LatLng SYDNEY = new LatLng(-33.87365, 151.20689);

    private static final LatLng ADELAIDE = new LatLng(-34.92873, 138.59995);

    private static final LatLng PERTH = new LatLng(-31.952854, 115.857342);

    private static final LatLng ALICE_SPRINGS = new LatLng(-24.6980, 133.8807);

    private MarkerDemoBinding binding;

    /** Demonstrates customizing the info window and/or its contents. */
    class CustomInfoWindowAdapter implements InfoWindowAdapter {

        // These are both viewgroups containing an ImageView with id "badge" and two TextViews with
        // id
        // "title" and "snippet".
        private final View mWindow;

        private final View mContents;

        CustomInfoWindowAdapter() {
            mWindow = getLayoutInflater().inflate(R.layout.custom_info_window, null);
            mContents = getLayoutInflater().inflate(R.layout.custom_info_contents, null);
        }

        @Override
        public View getInfoWindow(Marker marker) {
            if (binding.customInfoWindowOptions.getCheckedRadioButtonId()
                    != R.id.custom_info_window) {
                // This means that getInfoContents will be called.
                return null;
            }
            render(marker, mWindow);
            return mWindow;
        }

        @Override
        public View getInfoContents(Marker marker) {
            if (binding.customInfoWindowOptions.getCheckedRadioButtonId()
                    != R.id.custom_info_contents) {
                // This means that the default info contents will be used.
                return null;
            }
            render(marker, mContents);
            return mContents;
        }

        private void render(Marker marker, View view) {
            int badge;
            // Use the equals() method on a Marker to check for equals.  Do not use ==.
            if (marker.equals(mBrisbane)) {
                badge = R.drawable.badge_qld;
            } else if (marker.equals(mAdelaide)) {
                badge = R.drawable.badge_sa;
            } else if (marker.equals(mSydney)) {
                badge = R.drawable.badge_nsw;
            } else if (marker.equals(mMelbourne)) {
                badge = R.drawable.badge_victoria;
            } else if (marker.equals(mPerth)) {
                badge = R.drawable.badge_wa;
            } else if (marker.equals(mDarwin1)) {
                badge = R.drawable.badge_nt;
            } else if (marker.equals(mDarwin2)) {
                badge = R.drawable.badge_nt;
            } else if (marker.equals(mDarwin3)) {
                badge = R.drawable.badge_nt;
            } else if (marker.equals(mDarwin4)) {
                badge = R.drawable.badge_nt;
            } else {
                // Passing 0 to setImageResource will clear the image view.
                badge = 0;
            }
            ((ImageView) view.findViewById(R.id.badge)).setImageResource(badge);

            String title = marker.getTitle();
            TextView titleUi = view.findViewById(R.id.title);
            if (title != null) {
                // Spannable string allows us to edit the formatting of the text.
                SpannableString titleText = new SpannableString(title);
                titleText.setSpan(new ForegroundColorSpan(Color.RED), 0, titleText.length(), 0);
                titleUi.setText(titleText);
            } else {
                titleUi.setText("");
            }

            String snippet = marker.getSnippet();
            TextView snippetUi = view.findViewById(R.id.snippet);
            if (snippet != null && snippet.length() > 12) {
                SpannableString snippetText = new SpannableString(snippet);
                snippetText.setSpan(new ForegroundColorSpan(Color.MAGENTA), 0, 10, 0);
                snippetText.setSpan(new ForegroundColorSpan(Color.BLUE), 12, snippet.length(), 0);
                snippetUi.setText(snippetText);
            } else {
                snippetUi.setText("");
            }
        }
    }

    private GoogleMap mMap;

    private Marker mPerth;

    private Marker mSydney;

    private Marker mBrisbane;

    private Marker mAdelaide;

    private Marker mMelbourne;

    private Marker mDarwin1;
    private Marker mDarwin2;
    private Marker mDarwin3;
    private Marker mDarwin4;

    /**
     * Keeps track of the last selected marker (though it may no longer be selected). This is useful
     * for refreshing the info window.
     */
    private Marker mLastSelectedMarker;

    private final List<Marker> mMarkerRainbow = new ArrayList<>();

    private final Random mRandom = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = MarkerDemoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.rotationSeekBar.setMax(360);
        binding.rotationSeekBar.setOnSeekBarChangeListener(this);

        binding.customInfoWindowOptions.setOnCheckedChangeListener(
                new OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup group, int checkedId) {
                        if (mLastSelectedMarker != null
                                && mLastSelectedMarker.isInfoWindowShown()) {
                            // Refresh the info window when the info window's content has changed.
                            mLastSelectedMarker.showInfoWindow();
                        }
                    }
                });

        binding.clearMap.setOnClickListener(v -> onClearMap());
        binding.resetMap.setOnClickListener(v -> onResetMap());
        binding.flat.setOnClickListener(v -> onToggleFlat());

        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        new OnMapAndViewReadyListener(mapFragment, this);

        applyInsets(binding.mapContainer);
    }

    @Override
    public void onMapReady(GoogleMap map) {
        mMap = map;

        // Hide the zoom controls as the button panel will cover it.
        mMap.getUiSettings().setZoomControlsEnabled(false);

        // Add lots of markers to the map.
        addMarkersToMap();

        // Setting an info window adapter allows us to change the both the contents and look of the
        // info window.
        mMap.setInfoWindowAdapter(new CustomInfoWindowAdapter());

        // Set listeners for marker events.  See the bottom of this class for their behavior.
        mMap.setOnMarkerClickListener(this);
        mMap.setOnInfoWindowClickListener(this);
        mMap.setOnMarkerDragListener(this);
        mMap.setOnInfoWindowCloseListener(this);
        mMap.setOnInfoWindowLongClickListener(this);

        // Override the default content description on the view, for accessibility mode.
        // Ideally this string would be localised.
        mMap.setContentDescription("Map with lots of markers.");

        LatLngBounds bounds =
                new LatLngBounds.Builder()
                        .include(PERTH)
                        .include(SYDNEY)
                        .include(ADELAIDE)
                        .include(BRISBANE)
                        .include(MELBOURNE)
                        .include(DARWIN)
                        .build();
        mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 50));
    }

    private void addMarkersToMap() {
        // Uses a colored icon.
        mBrisbane =
                mMap.addMarker(
                        new MarkerOptions()
                                .position(BRISBANE)
                                .title("Brisbane")
                                .snippet("Population: 2,074,200")
                                .icon(
                                        BitmapDescriptorFactory.defaultMarker(
                                                BitmapDescriptorFactory.HUE_AZURE)));

        // Uses a custom icon with the info window popping out of the center of the icon.
        mSydney =
                mMap.addMarker(
                        new MarkerOptions()
                                .position(SYDNEY)
                                .title("Sydney")
                                .snippet("Population: 4,627,300")
                                .icon(BitmapDescriptorFactory.fromResource(R.drawable.arrow))
                                .infoWindowAnchor(0.5f, 0.5f));

        // Creates a draggable marker. Long press to drag.
        mMelbourne =
                mMap.addMarker(
                        new MarkerOptions()
                                .position(MELBOURNE)
                                .title("Melbourne")
                                .snippet(getString(R.string.melbourne_drag_snippet))
                                .icon(
                                        vectorToBitmap(
                                                R.drawable.ic_drag_pan,
                                                Color.parseColor("#E65100")))
                                .draggable(true));

        // Place four markers on top of each other with differing z-indexes.
        mDarwin1 =
                mMap.addMarker(
                        new MarkerOptions()
                                .position(DARWIN)
                                .title("Darwin Marker 1")
                                .snippet("z-index 1")
                                .zIndex(1));
        mDarwin2 =
                mMap.addMarker(
                        new MarkerOptions()
                                .position(DARWIN)
                                .title("Darwin Marker 2")
                                .snippet("z-index 2")
                                .zIndex(2));
        mDarwin3 =
                mMap.addMarker(
                        new MarkerOptions()
                                .position(DARWIN)
                                .title("Darwin Marker 3")
                                .snippet("z-index 3")
                                .zIndex(3));
        mDarwin4 =
                mMap.addMarker(
                        new MarkerOptions()
                                .position(DARWIN)
                                .title("Darwin Marker 4")
                                .snippet("z-index 4")
                                .zIndex(4));

        // A few more markers for good measure.
        mPerth =
                mMap.addMarker(
                        new MarkerOptions()
                                .position(PERTH)
                                .title("Perth")
                                .snippet("Population: 1,738,800"));
        mAdelaide =
                mMap.addMarker(
                        new MarkerOptions()
                                .position(ADELAIDE)
                                .title("Adelaide")
                                .snippet("Population: 1,213,000"));

        // Vector drawable resource as a marker icon.
        mMap.addMarker(
                new MarkerOptions()
                        .position(ALICE_SPRINGS)
                        .icon(vectorToBitmap(R.drawable.ic_android, Color.parseColor("#A4C639")))
                        .title("Alice Springs"));

        if (mMelbourne != null) {
            mMelbourne.showInfoWindow();
            mLastSelectedMarker = mMelbourne;
        }

        // Creates a marker rainbow demonstrating how to create default marker icons of different
        // hues (colors).
        float rotation = binding.rotationSeekBar.getProgress();
        boolean flat = binding.flat.isChecked();

        int numMarkersInRainbow = 12;
        for (int i = 0; i < numMarkersInRainbow; i++) {
            Marker marker =
                    mMap.addMarker(
                            new MarkerOptions()
                                    .position(
                                            new LatLng(
                                                    -30
                                                            + 10
                                                                    * Math.sin(
                                                                            i
                                                                                    * Math.PI
                                                                                    / (numMarkersInRainbow
                                                                                            - 1)),
                                                    135
                                                            - 10
                                                                    * Math.cos(
                                                                            i
                                                                                    * Math.PI
                                                                                    / (numMarkersInRainbow
                                                                                            - 1))))
                                    .title("Marker " + i)
                                    .icon(
                                            BitmapDescriptorFactory.defaultMarker(
                                                    i * 360 / numMarkersInRainbow))
                                    .flat(flat)
                                    .rotation(rotation));
            mMarkerRainbow.add(marker);
        }
    }

    /**
     * Demonstrates converting a {@link Drawable} to a {@link BitmapDescriptor}, for use as a marker
     * icon.
     */
    private BitmapDescriptor vectorToBitmap(@DrawableRes int id, @ColorInt int color) {
        Drawable vectorDrawable = ResourcesCompat.getDrawable(getResources(), id, null);
        Bitmap bitmap =
                Bitmap.createBitmap(
                        vectorDrawable.getIntrinsicWidth(),
                        vectorDrawable.getIntrinsicHeight(),
                        Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        DrawableCompat.setTint(vectorDrawable, color);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    private boolean checkReady() {
        if (mMap == null) {
            Toast.makeText(this, R.string.map_not_ready, Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void onClearMap() {
        if (!checkReady()) {
            return;
        }
        mMap.clear();
    }

    private void onResetMap() {
        if (!checkReady()) {
            return;
        }
        // Clear the map because we don't want duplicates of the markers.
        mMap.clear();
        addMarkersToMap();
    }

    private void onToggleFlat() {
        if (!checkReady()) {
            return;
        }
        boolean flat = binding.flat.isChecked();
        for (Marker marker : mMarkerRainbow) {
            marker.setFlat(flat);
        }
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        if (!checkReady()) {
            return;
        }
        float rotation = seekBar.getProgress();
        for (Marker marker : mMarkerRainbow) {
            marker.setRotation(rotation);
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
        // Do nothing.
    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        // Do nothing.
    }

    //
    // Marker related listeners.
    //

    @Override
    public boolean onMarkerClick(final Marker marker) {
        if (marker.equals(mPerth)) {
            // This causes the marker at Perth to bounce into position when it is clicked.
            final Handler handler = new Handler(Looper.getMainLooper());
            final long start = SystemClock.uptimeMillis();
            final long duration = 1500;

            final Interpolator interpolator = new BounceInterpolator();

            handler.post(
                    new Runnable() {
                        @Override
                        public void run() {
                            long elapsed = SystemClock.uptimeMillis() - start;
                            float t =
                                    Math.max(
                                            1
                                                    - interpolator.getInterpolation(
                                                            (float) elapsed / duration),
                                            0);
                            marker.setAnchor(0.5f, 1.0f + 2 * t);

                            if (t > 0.0) {
                                // Post again 16ms later.
                                handler.postDelayed(this, 16);
                            }
                        }
                    });
        } else if (marker.equals(mAdelaide)) {
            // This causes the marker at Adelaide to change color and alpha.
            marker.setIcon(BitmapDescriptorFactory.defaultMarker(mRandom.nextFloat() * 360));
            marker.setAlpha(mRandom.nextFloat());
        }

        // Markers have a z-index that is settable and gettable.
        float zIndex = marker.getZIndex() + 1.0f;
        marker.setZIndex(zIndex);
        Toast.makeText(this, marker.getTitle() + " z-index set to " + zIndex, Toast.LENGTH_SHORT)
                .show();

        mLastSelectedMarker = marker;
        // We return false to indicate that we have not consumed the event and that we wish
        // for the default behavior to occur (which is for the camera to move such that the
        // marker is centered and for the marker's info window to open, if it has one).
        return false;
    }

    @Override
    public void onInfoWindowClick(Marker marker) {
        Toast.makeText(this, "Click Info Window", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onInfoWindowClose(Marker marker) {
        // Toast.makeText(this, "Close Info Window", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onInfoWindowLongClick(Marker marker) {
        Toast.makeText(this, "Info Window long click", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onMarkerDragStart(Marker marker) {
        binding.topText.setVisibility(View.VISIBLE);
        binding.topText.setText(R.string.on_marker_drag_start);
    }

    @Override
    public void onMarkerDragEnd(Marker marker) {
        binding.topText.setVisibility(View.VISIBLE);
        binding.topText.setText(R.string.on_marker_drag_end);
    }

    @Override
    public void onMarkerDrag(Marker marker) {
        binding.topText.setVisibility(View.VISIBLE);
        binding.topText.setText(
                getString(
                        R.string.on_marker_drag,
                        marker.getPosition().latitude,
                        marker.getPosition().longitude));
    }
}
// [END maps_android_sample_marker]
