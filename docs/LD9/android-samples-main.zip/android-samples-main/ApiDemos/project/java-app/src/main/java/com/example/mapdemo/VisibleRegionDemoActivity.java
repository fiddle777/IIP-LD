// Copyright 2026 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.example.mapdemo;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.animation.Interpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.Toast;
import androidx.appcompat.widget.PopupMenu;
import com.example.common_ui.R;
import com.example.common_ui.catalog.Complexity;
import com.example.common_ui.catalog.Framework;
import com.example.common_ui.catalog.Sample;
import com.example.common_ui.databinding.VisibleRegionDemoBinding;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;

/**
 * This shows how to use setPadding to allow overlays that obscure part of the map without obscuring
 * the map UI or copyright notices.
 */
@Sample(
        id = "com.example.mapdemo.VisibleRegionDemoActivity",
        title = "Visible Region & Projection",
        description = "Querying current viewport bounding coordinates via GoogleMap.projection.",
        category = "Camera Controls",
        complexity = Complexity.SIMPLE,
        tags = {"#camera", "#projection", "#visibleregion", "#latlngbounds"},
        apiCalls = {
            "GoogleMap.setPadding(int, int, int, int)",
            "GoogleMap.moveCamera(CameraUpdate)",
            "GoogleMap.cameraPosition",
            "GoogleMap.setOnCameraIdleListener(OnCameraIdleListener)"
        },
        purpose =
                "Demonstrates reading GoogleMap.projection.visibleRegion and calculating viewport bounds dynamically.",
        successCriteria =
                "Bounding coordinates update live in the UI as the camera pans and zooms.",
        failureIndicators = "Projection returns null or stale LatLng bounds after camera idle.",
        framework = Framework.JAVA_VIEWS)
// [START maps_android_sample_visible_region]
public class VisibleRegionDemoActivity extends SamplesBaseActivity
        implements OnMapAndViewReadyListener.OnGlobalLayoutAndMapReadyListener {

    /** Note that this may be null if the Google Play services APK is not available. */
    private GoogleMap mMap;

    private static final LatLng SOH = new LatLng(-33.85704, 151.21522);

    private static final LatLng SFO = new LatLng(37.614631, -122.385153);

    private static final LatLngBounds AUS =
            new LatLngBounds(new LatLng(-44, 113), new LatLng(-10, 154));

    private VisibleRegionDemoBinding binding;

    /** Keep track of current values for padding, so we can animate from them. */
    int currentLeft = 0;

    int currentTop = 0;

    int currentRight = 0;

    int currentBottom = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = VisibleRegionDemoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.cameraActionsButton.setOnClickListener(
                v -> {
                    PopupMenu popup = new PopupMenu(this, v);
                    popup.getMenuInflater().inflate(R.menu.visible_region_menu, popup.getMenu());
                    popup.setOnMenuItemClickListener(
                            item -> {
                                int itemId = item.getItemId();
                                if (itemId == R.id.menu_action_no_padding) {
                                    setNoPadding();
                                    return true;
                                } else if (itemId == R.id.menu_action_more_padding) {
                                    setMorePadding(v);
                                    return true;
                                } else if (itemId == R.id.menu_action_opera_house) {
                                    moveToOperaHouse(v);
                                    return true;
                                } else if (itemId == R.id.menu_action_sfo) {
                                    moveToSFO(v);
                                    return true;
                                } else if (itemId == R.id.menu_action_australia) {
                                    moveToAUS(v);
                                    return true;
                                }
                                return false;
                            });
                    popup.show();
                });

        binding.vrNormalButton.setOnClickListener(v -> setNoPadding());
        binding.vrMorePaddedButton.setOnClickListener(this::setMorePadding);
        binding.vrSohButton.setOnClickListener(this::moveToOperaHouse);
        binding.vrSfoButton.setOnClickListener(this::moveToSFO);
        binding.vrAusButton.setOnClickListener(this::moveToAUS);

        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        new OnMapAndViewReadyListener(mapFragment, this);

        applyInsets(binding.mapContainer);
    }

    @Override
    public void onMapReady(GoogleMap map) {
        mMap = map;

        // Move to a place with indoor (SFO airport).
        mMap.setPadding(currentLeft, currentTop, currentRight, currentBottom);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(SFO, 18));
        // Add a marker to the Opera House.
        mMap.addMarker(new MarkerOptions().position(SOH).title("Sydney Opera House"));
        // Add a camera idle listener.
        mMap.setOnCameraIdleListener(this::updateCameraDisplay);
        updateCameraDisplay();
    }

    private void updateCameraDisplay() {
        if (mMap == null) return;
        CameraPosition pos = mMap.getCameraPosition();
        binding.cameraTargetText.setText(
                getString(
                        R.string.camera_target_format, pos.target.latitude, pos.target.longitude));
        binding.cameraDetailsText.setText(
                getString(R.string.camera_details_format, pos.zoom, pos.tilt, pos.bearing));
    }

    /**
     * Checks if the map is ready (which depends on whether the Google Play services APK is
     * available. This should be called prior to calling any methods on GoogleMap.
     */
    private boolean checkReady() {
        if (mMap == null) {
            Toast.makeText(this, R.string.map_not_ready, Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    public void moveToOperaHouse(View view) {
        if (!checkReady()) {
            return;
        }
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(SOH, 16));
    }

    public void moveToSFO(View view) {
        if (!checkReady()) {
            return;
        }
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(SFO, 18));
    }

    public void moveToAUS(View view) {
        if (!checkReady()) {
            return;
        }
        mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(AUS, 0));
    }

    private void setNoPadding() {
        if (!checkReady()) {
            return;
        }
        animatePadding(0, 0, 0, 0);
    }

    public void setMorePadding(View view) {
        if (!checkReady()) {
            return;
        }
        View mapView = (getSupportFragmentManager().findFragmentById(R.id.map)).getView();
        int left = 0;
        int top = 0;
        int right = mapView.getWidth() / 3;
        int bottom = mapView.getHeight() / 4;
        animatePadding(left, top, right, bottom);
    }

    public void animatePadding(
            final int toLeft, final int toTop, final int toRight, final int toBottom) {

        final Handler handler = new Handler(Looper.getMainLooper());
        final long start = SystemClock.uptimeMillis();
        final long duration = 1000;

        final Interpolator interpolator = new OvershootInterpolator();

        final int startLeft = currentLeft;
        final int startTop = currentTop;
        final int startRight = currentRight;
        final int startBottom = currentBottom;

        currentLeft = toLeft;
        currentTop = toTop;
        currentRight = toRight;
        currentBottom = toBottom;

        handler.post(
                new Runnable() {
                    @Override
                    public void run() {
                        long elapsed = SystemClock.uptimeMillis() - start;
                        float t = interpolator.getInterpolation((float) elapsed / duration);

                        int left = (int) (startLeft + ((toLeft - startLeft) * t));
                        int top = (int) (startTop + ((toTop - startTop) * t));
                        int right = (int) (startRight + ((toRight - startRight) * t));
                        int bottom = (int) (startBottom + ((toBottom - startBottom) * t));

                        mMap.setPadding(left, top, right, bottom);

                        if (elapsed < duration) {
                            // Post again 16ms later.
                            handler.postDelayed(this, 16);
                        }
                    }
                });
    }
}
// [END maps_android_sample_visible_region]
