// Copyright 2020 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.example.mapdemo;

import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import com.example.common_ui.catalog.Complexity;
import com.example.common_ui.catalog.Framework;
import com.example.common_ui.catalog.Sample;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.TileOverlay;
import com.google.android.gms.maps.model.TileOverlayOptions;
import com.google.android.gms.maps.model.TileProvider;
import com.google.android.gms.maps.model.UrlTileProvider;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Locale;

/** This demonstrates how to add a tile overlay to a map. */
@Sample(
        id = "tile_overlay",
        title = "Tile Overlays & TileProvider",
        description = "Custom TileProvider rendering coordinate grid tiles and custom imagery.",
        category = "Overlays & Tiles",
        complexity = Complexity.SIMPLE,
        tags = {"#overlays", "#tiles", "#tileprovider", "#customtiles"},
        purpose =
                "Demonstrates generating custom raster tiles on the fly using a custom TileProvider (coordinate overlays).",
        successCriteria = "Tile grid numbers (x, y, zoom) render cleanly over the base map.",
        failureIndicators = "Tile rendering blocks UI thread or tiles fail to fetch on pan.",
        framework = Framework.JAVA_VIEWS)
public class TileOverlayDemoActivity extends SamplesBaseActivity
        implements OnSeekBarChangeListener, OnMapReadyCallback {

    private static final int TRANSPARENCY_MAX = 100;

    /** This returns moon tiles. */
    private static final String MOON_MAP_URL_FORMAT =
            "https://mw1.google.com/mw-planetary/lunar/lunarmaps_v1/clem_bw/%d/%d/%d.jpg";

    private TileOverlay moonTiles;
    private com.example.common_ui.databinding.TileOverlayDemoBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding =
                com.example.common_ui.databinding.TileOverlayDemoBinding.inflate(
                        getLayoutInflater());
        setContentView(binding.getRoot());

        binding.transparencySeekBar.setMax(TRANSPARENCY_MAX);
        binding.transparencySeekBar.setProgress(0);
        binding.fadeInToggle.setOnClickListener(v -> setFadeIn());

        SupportMapFragment mapFragment =
                (SupportMapFragment)
                        getSupportFragmentManager()
                                .findFragmentById(com.example.common_ui.R.id.map);
        mapFragment.getMapAsync(this);

        applyInsets(binding.mapContainer);
    }

    @Override
    public void onMapReady(GoogleMap map) {
        map.setMapType(GoogleMap.MAP_TYPE_NONE);

        TileProvider tileProvider =
                new UrlTileProvider(256, 256) {
                    @Override
                    public synchronized URL getTileUrl(int x, int y, int zoom) {
                        // The moon tile coordinate system is reversed.  This is not normal.
                        int reversedY = (1 << zoom) - y - 1;
                        String s =
                                String.format(Locale.US, MOON_MAP_URL_FORMAT, zoom, x, reversedY);
                        URL url = null;
                        try {
                            url = new URL(s);
                        } catch (MalformedURLException e) {
                            throw new AssertionError(e);
                        }
                        return url;
                    }
                };

        moonTiles = map.addTileOverlay(new TileOverlayOptions().tileProvider(tileProvider));
        binding.transparencySeekBar.setOnSeekBarChangeListener(this);
    }

    private void setFadeIn() {
        if (moonTiles == null) {
            return;
        }
        moonTiles.setFadeIn(binding.fadeInToggle.isChecked());
    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {}

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {}

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        if (moonTiles != null) {
            moonTiles.setTransparency((float) progress / (float) TRANSPARENCY_MAX);
        }
    }
}
